#!/bin/bash

\rm -f uncompress* make_blas.inc make_lapack.inc make_wannier90.sys
